package com.example.movieshelf.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.movieshelf.R
import com.example.movieshelf.databinding.ItemMovieBinding
import com.example.movieshelf.model.Movie
import com.example.movieshelf.utils.ApiConstants

class MovieAdapter(private val context: Context, private val onMovieClick: (Movie) -> Unit) : RecyclerView.Adapter<MovieAdapter.MovieHolder>() {
    private var list = mutableListOf<Movie>()

    inner class MovieHolder(var binding: ItemMovieBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieHolder {
        val binding = ItemMovieBinding.inflate(LayoutInflater.from(context), parent, false)
        return MovieHolder(binding)
    }

    override fun onBindViewHolder(holder: MovieHolder, position: Int) {
        val movie = list[position]
        holder.binding.textMovieTitle.text = movie.title
        holder.binding.textMovieDate.text = movie.releaseDate ?: "Sin fecha"
        holder.binding.textMovieDescription.text = movie.description?.ifBlank { "Sin descripción disponible" } ?: "Sin descripción disponible"
        holder.binding.textMovieRating.text = "${"%.1f".format(movie.voteAverage)}"

        val posterUrl = movie.posterPath?.let { ApiConstants.IMAGE_BASE_URL + it }

        Glide.with(context).load(posterUrl).placeholder(R.drawable.not_found_image).into(holder.binding.imageMoviePoster)

        holder.binding.root.setOnClickListener {
            onMovieClick(movie)
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    fun setMovies(movies: List<Movie>) {
        list.clear()
        list.addAll(movies)
        notifyDataSetChanged()
    }
}