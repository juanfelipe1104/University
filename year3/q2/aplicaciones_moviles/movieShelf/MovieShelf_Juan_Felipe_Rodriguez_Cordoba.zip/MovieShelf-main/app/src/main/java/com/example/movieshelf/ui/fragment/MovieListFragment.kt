package com.example.movieshelf.ui.fragment

import android.content.res.Configuration
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.movieshelf.R
import com.example.movieshelf.ui.adapter.MovieAdapter
import com.example.movieshelf.databinding.FragmentMovieListBinding
import com.example.movieshelf.model.Movie
import com.example.movieshelf.model.MovieResponse
import com.example.movieshelf.utils.ApiConstants
import com.google.android.material.snackbar.Snackbar
import com.google.gson.Gson

class MovieListFragment : Fragment() {

    private lateinit var binding: FragmentMovieListBinding
    private lateinit var adapterMovies: MovieAdapter
    private val allMovies = mutableListOf<Movie>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?, ): View {
        binding = FragmentMovieListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        instances()
        initGUI()
        getJSONData()
    }

    private fun instances() {
        adapterMovies = MovieAdapter(requireContext()) {
            val bundle = bundleOf("movieId" to it.id)

            findNavController().navigate(R.id.action_movieListFragment_to_movieDetailsFragment, bundle)
        }
    }

    private fun initGUI() {
        binding.recyclerMovies.adapter = adapterMovies

        binding.buttonGoToFavorites.setOnClickListener {
            findNavController().navigate(R.id.action_movieListFragment_to_favoritesFragment)
        }

        if (resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) {
            binding.recyclerMovies.layoutManager =
                LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
        } else {
            binding.recyclerMovies.layoutManager =
                GridLayoutManager(requireContext(), 2, LinearLayoutManager.VERTICAL, false)
        }
    }

    private fun getJSONData() {
        binding.progressMovies.isVisible = true

        val url = "${ApiConstants.TMDB_BASE_URL}movie/popular?language=es-ES&page=1"

        val request = object : JsonObjectRequest(url,
            { response ->
                binding.progressMovies.isVisible = false
                val gson = Gson()
                val movieResponse = gson.fromJson(response.toString(), MovieResponse::class.java)

                allMovies.clear()
                allMovies.addAll(movieResponse.results)

                adapterMovies.setMovies(allMovies)
            },
            {
                binding.progressMovies.isVisible = false
                Snackbar.make(binding.root, "Error al cargar peliculas", Snackbar.LENGTH_LONG).show()
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                return hashMapOf(
                    "Authorization" to ApiConstants.TMDB_BEARER_TOKEN,
                    "accept" to "application/json"
                )
            }
        }

        Volley.newRequestQueue(requireContext()).add(request)
    }
}