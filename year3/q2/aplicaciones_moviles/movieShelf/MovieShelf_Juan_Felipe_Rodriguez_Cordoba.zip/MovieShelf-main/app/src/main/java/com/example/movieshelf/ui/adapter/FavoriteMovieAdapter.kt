package com.example.movieshelf.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.movieshelf.databinding.ItemFavoriteMovieBinding
import com.example.movieshelf.model.FavoriteMovie
import com.example.movieshelf.utils.ApiConstants

class FavoriteMovieAdapter(
    private val context: Context,
    private val onMovieClick: (FavoriteMovie) -> Unit,
    private val onRemoveClick: (FavoriteMovie) -> Unit
) : RecyclerView.Adapter<FavoriteMovieAdapter.FavoriteMovieHolder>() {

    private val list = mutableListOf<FavoriteMovie>()

    inner class FavoriteMovieHolder(val binding: ItemFavoriteMovieBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteMovieHolder {
        val binding = ItemFavoriteMovieBinding.inflate(LayoutInflater.from(context), parent, false)
        return FavoriteMovieHolder(binding)
    }

    override fun onBindViewHolder(holder: FavoriteMovieHolder, position: Int) {
        val movie = list[position]

        holder.binding.textFavoriteTitle.text = movie.title
        holder.binding.textFavoriteDate.text = movie.releaseDate ?: "Sin fecha"
        holder.binding.textFavoriteRating.text = "${"%.1f".format(movie.voteAverage)}"

        val posterUrl = movie.posterPath?.let { ApiConstants.IMAGE_BASE_URL + it }

        Glide.with(context).load(posterUrl).centerCrop().placeholder(android.R.drawable.ic_menu_gallery).into(holder.binding.imageFavoritePoster)

        holder.binding.root.setOnClickListener {
            onMovieClick(movie)
        }

        holder.binding.buttonRemoveFavorite.setOnClickListener {
            onRemoveClick(movie)
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    fun setMovies(movies: List<FavoriteMovie>) {
        list.clear()
        list.addAll(movies)
        notifyDataSetChanged()
    }
}