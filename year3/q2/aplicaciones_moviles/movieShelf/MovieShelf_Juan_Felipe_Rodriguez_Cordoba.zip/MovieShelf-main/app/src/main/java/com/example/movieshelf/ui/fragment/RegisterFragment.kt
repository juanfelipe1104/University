package com.example.movieshelf.ui.fragment

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.movieshelf.R
import com.example.movieshelf.databinding.FragmentRegisterBinding
import com.example.movieshelf.model.User
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class RegisterFragment: Fragment() {
    private lateinit var binding: FragmentRegisterBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase

    override fun onAttach(context: Context) {
        super.onAttach(context)
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance("https://movieshelf-6b147-default-rtdb.firebaseio.com/")
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentRegisterBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        actions()
    }

    private fun actions(){
        binding.buttonRegister.setOnClickListener {
            registerUser()
        }
        binding.textViewGoToLogin.setOnClickListener {
            findNavController().popBackStack()
        }
    }

    private fun registerUser(){
        val name = binding.editTextName.text.toString().trim()
        val email = binding.editTextEmail.text.toString().trim()
        val password = binding.editTextPassword.text.toString().trim()
        val repeatPassword = binding.editTextRepeatPassword.text.toString().trim()

        if(!validateForm(name, email, password, repeatPassword)){
            return
        }

        auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener {
            if(it.isSuccessful){
                saveUserInDatabase(name, email)
            }
            else{
                Snackbar.make(binding.root, "No se pudo registrar el usuario", Snackbar.LENGTH_LONG).show()
            }
        }
    }

    private fun validateForm(name: String, email: String, password: String, repeatPassword: String): Boolean{
        if(name.isEmpty()){
            binding.editTextName.error = "Introduce tu nombre"
            return false
        }
        if(email.isEmpty()){
            binding.editTextEmail.error = "Introduce tu correo"
            return false
        }
        if(password.isEmpty()){
            binding.editTextPassword.error = "Introduce una contraseña"
            return false
        }
        if(repeatPassword.isEmpty()){
            binding.editTextRepeatPassword.error = "Repite la contraseña"
            return false
        }
        if(password.length < 8){
            binding.editTextPassword.error = "La contraseña debe tener al menos 8 caracteres"
            return false
        }
        if(password != repeatPassword){
            binding.editTextRepeatPassword.error = "Las contraseñas no coinciden"
            return false
        }
        return true
    }

    private fun saveUserInDatabase(name: String, email: String){
        val currentUser = auth.currentUser
        if(currentUser == null){
            Snackbar.make(binding.root, "No se encontró el usuario registrado", Snackbar.LENGTH_LONG).show()
            return
        }
        val uid = currentUser.uid
        val user = User(uid, name, email)
        database.reference.child("users").child(uid).setValue(user).addOnCompleteListener {
            if(it.isSuccessful){
                Snackbar.make(binding.root, "Usuario registrado correctamente", Snackbar.LENGTH_LONG).show()
                findNavController().navigate(R.id.action_registerFragment_to_movieListFragment)
            }
            else{
                Snackbar.make(binding.root, "Fallo en el proceso de registro", Snackbar.LENGTH_LONG).show()
            }
        }
    }
}