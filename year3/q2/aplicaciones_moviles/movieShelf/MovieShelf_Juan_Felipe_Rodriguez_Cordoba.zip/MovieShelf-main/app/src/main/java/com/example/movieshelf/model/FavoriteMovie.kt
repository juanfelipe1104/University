package com.example.movieshelf.model

data class FavoriteMovie(
    val id: Int = 0,
    val title: String = "",
    val description: String = "",
    val posterPath: String? = null,
    val backdropPath: String? = null,
    val releaseDate: String? = null,
    val voteAverage: Double = 0.0
)