package com.example.movieshelf.model

import com.google.gson.annotations.SerializedName

data class MovieDetail(
    val id: Int,
    val title: String,

    @SerializedName("overview")
    val description: String,

    @SerializedName("poster_path")
    val posterPath: String?,

    @SerializedName("backdrop_path")
    val backdropPath: String?,

    @SerializedName("release_date")
    val releaseDate: String?,

    @SerializedName("vote_average")
    val voteAverage: Double,

    val runtime: Int?,

    val genres: List<Genre>,

    val tagline: String?
)

data class Genre(
    val id: Int,
    val name: String
)