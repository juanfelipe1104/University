package com.example.movieshelf.ui.fragment

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.bumptech.glide.Glide
import com.example.movieshelf.databinding.FragmentMovieDetailBinding
import com.example.movieshelf.model.MovieDetail
import com.example.movieshelf.utils.ApiConstants
import com.google.android.material.snackbar.Snackbar
import com.google.gson.Gson
import com.example.movieshelf.model.FavoriteMovie
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class MovieDetailFragment : Fragment() {

    private lateinit var binding: FragmentMovieDetailBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase

    private var movieId: Int = -1
    private var currentMovie: MovieDetail? = null

    override fun onAttach(context: Context) {
        super.onAttach(context)
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance("https://movieshelf-6b147-default-rtdb.firebaseio.com/")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        movieId = arguments?.getInt("movieId") ?: -1
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?, ): View {
        binding = FragmentMovieDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (movieId == -1) {
            Snackbar.make(binding.root, "No se encontró la película", Snackbar.LENGTH_LONG).show()
            return
        }
        getMovieDetail()
        actions()
    }

    private fun actions() {
        binding.buttonAddFavorite.setOnClickListener {
            val movie = currentMovie

            if (movie == null) {
                Snackbar.make(
                    binding.root,
                    "La película aún no ha cargado",
                    Snackbar.LENGTH_SHORT
                ).show()
            } else {
                addMovieToFavorites(movie)
            }
        }
    }

    private fun addMovieToFavorites(movie: MovieDetail) {
        val currentUser = auth.currentUser!!

        val favoriteMovie = FavoriteMovie(
            movie.id,
            movie.title,
            movie.description,
            movie.posterPath,
            movie.backdropPath,
            movie.releaseDate,
            movie.voteAverage
        )

        database.reference.child("favorites").child(currentUser.uid)
            .child(movie.id.toString()).setValue(favoriteMovie).addOnSuccessListener {
                Snackbar.make(binding.root, "${movie.title} añadida a favoritos", Snackbar.LENGTH_LONG).show()
            }
            .addOnFailureListener {
                Snackbar.make(binding.root, "No se pudo añadir a favoritos", Snackbar.LENGTH_LONG).show()
            }
    }

    private fun getMovieDetail() {
        val url = "${ApiConstants.TMDB_BASE_URL}movie/$movieId?language=es-ES"
        val request = object : JsonObjectRequest(url,
            { response ->
                val gson = Gson()
                val movieDetail = gson.fromJson(response.toString(), MovieDetail::class.java)
                currentMovie = movieDetail
                showMovieDetail(movieDetail)
            },
            {
                Snackbar.make(binding.root, "Error al cargar la pelicula", Snackbar.LENGTH_LONG).show()
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                return hashMapOf(
                    "Authorization" to ApiConstants.TMDB_BEARER_TOKEN,
                    "accept" to "application/json"
                )
            }
        }

        Volley.newRequestQueue(requireContext()).add(request)
    }

    private fun showMovieDetail(movie: MovieDetail) {
        binding.textMovieTitle.text = movie.title
        binding.textMovieTagline.text = movie.tagline.orEmpty()
        binding.textMovieTagline.visibility = if (movie.tagline.isNullOrBlank()) View.GONE else View.VISIBLE

        val releaseDate = movie.releaseDate ?: "Sin fecha"
        val runtime = movie.runtime?.let { "$it min" } ?: "Sin duración"
        val rating = "%.1f".format(movie.voteAverage)

        binding.textMovieInfo.text = "$releaseDate · $runtime · ⭐ $rating"

        binding.textMovieGenres.text = if (movie.genres.isEmpty()) {
            "Sin géneros"
        } else {
            movie.genres.joinToString(", ") { it.name }
        }

        binding.textMovieDescription.text =
            movie.description.ifBlank { "Sin descripción disponible" }

        val imagePath = movie.backdropPath ?: movie.posterPath

        val imageUrl = imagePath?.let {
            ApiConstants.IMAGE_BASE_URL + it
        }

        Glide.with(requireContext())
            .load(imageUrl)
            .centerCrop()
            .into(binding.imageMovieBackdrop)
    }
}