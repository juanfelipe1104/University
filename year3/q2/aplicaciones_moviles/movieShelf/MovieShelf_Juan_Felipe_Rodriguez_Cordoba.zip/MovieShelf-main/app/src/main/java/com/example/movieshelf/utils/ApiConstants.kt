package com.example.movieshelf.utils

object ApiConstants {
    const val TMDB_BASE_URL = "https://api.themoviedb.org/3/"
    const val TMDB_BEARER_TOKEN = "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIyYzA5MTViODNkNjIxYzQwNmIzZTZiMzVlN2JiMTNlOCIsIm5iZiI6MTc3ODQyNDM3Ny4wNjksInN1YiI6IjZhMDA5YTM5ZWVkNTQ5ODRhZGVjMjMxNCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.u3p0Mtw1Ew0QhFpzE60P0usLs9aqIljJ6pAx4p1J1Aw"
    const val IMAGE_BASE_URL = "https://image.tmdb.org/t/p/w500"
}