package com.example.movieshelf.ui.fragment

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.movieshelf.R
import com.example.movieshelf.ui.adapter.FavoriteMovieAdapter
import com.example.movieshelf.databinding.FragmentFavoritesBinding
import com.example.movieshelf.model.FavoriteMovie
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class FavoritesFragment : Fragment() {

    private lateinit var binding: FragmentFavoritesBinding
    private lateinit var adapterFavorites: FavoriteMovieAdapter
    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase

    private val favoriteMovies = mutableListOf<FavoriteMovie>()

    override fun onAttach(context: Context) {
        super.onAttach(context)
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance("https://movieshelf-6b147-default-rtdb.firebaseio.com/")
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentFavoritesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        instances()
        initGUI()
        getFavorites()
    }

    private fun instances() {
        adapterFavorites = FavoriteMovieAdapter(requireContext(),
            onMovieClick = {
                val bundle = bundleOf("movieId" to it.id)
                findNavController().navigate(R.id.action_favoritesFragment_to_movieDetailsFragment, bundle)
            },
            onRemoveClick = {
                removeFavorite(it)
            }
        )
    }

    private fun initGUI() {
        binding.recyclerFavorites.adapter = adapterFavorites

        if (resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) {
            binding.recyclerFavorites.layoutManager =
                LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
        } else {
            binding.recyclerFavorites.layoutManager =
                GridLayoutManager(requireContext(), 2, LinearLayoutManager.VERTICAL, false)
        }
    }

    private fun getFavorites() {
        val currentUser = auth.currentUser!!

        database.reference.child("favorites").child(currentUser.uid).get()
            .addOnSuccessListener {
                favoriteMovies.clear()
                for (child in it.children) {
                    val movie = child.getValue(FavoriteMovie::class.java)
                    if (movie != null) {
                        favoriteMovies.add(movie)
                    }
                }

                adapterFavorites.setMovies(favoriteMovies)
                showEmptyMessage(favoriteMovies.isEmpty())
            }
            .addOnFailureListener {
                Snackbar.make(binding.root, "No se pudieron cargar los favoritos", Snackbar.LENGTH_SHORT).show()
            }
    }

    private fun removeFavorite(movie: FavoriteMovie) {
        val currentUser = auth.currentUser!!

        database.reference.child("favorites").child(currentUser.uid)
            .child(movie.id.toString()).removeValue().addOnSuccessListener {
                Snackbar.make(binding.root, "${movie.title} eliminada de favoritos", Snackbar.LENGTH_LONG).show()
                getFavorites()
            }
            .addOnFailureListener {
                Snackbar.make(binding.root, "No se pudo eliminar el favorito", Snackbar.LENGTH_LONG).show()
            }
    }

    private fun showEmptyMessage(isEmpty: Boolean) {
        binding.textEmptyFavorites.isVisible = isEmpty
        binding.recyclerFavorites.isVisible = !isEmpty
    }
}