import '../constants/calculator_keys.dart';

class CalculatorEngine {
  static double evaluate(String expression) {
    List<String> tokens = _tokenize(expression);

    _resolveOperations(tokens, [CalculatorKeys.multiplyOperator, CalculatorKeys.divide]);

    _resolveOperations(tokens, [CalculatorKeys.sum, CalculatorKeys.subtract]);

    return double.parse(tokens[0]);
  }

  static String formatResult(double result) {
    if (result % 1 == 0) {
      return result.toInt().toString();
    }

    return result.toString();
  }

  static bool isOperator(String value) {
    return value == CalculatorKeys.sum ||
        value == CalculatorKeys.subtract ||
        value == CalculatorKeys.multiplyOperator ||
        value == CalculatorKeys.divide;
  }

  static List<String> _tokenize(String text) {
    List<String> tokens = [];
    String number = '';

    for (int i = 0; i < text.length; i++) {
      String character = text[i];

      if (isOperator(character)) {
        bool isNegativeSign =
            character == '-' &&
            number.isEmpty &&
            (tokens.isEmpty || isOperator(tokens.last));

        if (isNegativeSign) {
          number = '-';
          continue;
        }

        if (number.isEmpty || number == '-') {
          throw Exception('Expresión inválida');
        }

        tokens.add(number);
        tokens.add(character);
        number = '';
      } else if (character == CalculatorKeys.percent) {
        if (number.isEmpty || number == '-') {
          throw Exception('Porcentaje inválido');
        }

        double value = double.parse(number);
        number = (value / 100).toString();
      } else {
        number += character;
      }
    }

    if (number.isEmpty || number == '-') {
      throw Exception('Expresión inválida');
    }

    tokens.add(number);

    return tokens;
  }

  static double _applyOperation(double left, String operator, double right) {
    switch (operator) {
      case CalculatorKeys.sum:
        return left + right;

      case CalculatorKeys.subtract:
        return left - right;

      case CalculatorKeys.multiplyOperator:
        return left * right;

      case CalculatorKeys.divide:
        if (right == 0) {
          throw Exception('División entre cero');
        }
        return left / right;

      default:
        throw Exception('Operador inválido');
    }
  }

  static void _resolveOperations(List<String> tokens, List<String> operators) {
    int i = 0;

    while (i < tokens.length) {
      if (operators.contains(tokens[i])) {
        double left = double.parse(tokens[i - 1]);
        double right = double.parse(tokens[i + 1]);
        double result = _applyOperation(left, tokens[i], right);

        tokens.replaceRange(i - 1, i + 2, [result.toString()]);
        i = 0;
      } else {
        i++;
      }
    }
  }
}
