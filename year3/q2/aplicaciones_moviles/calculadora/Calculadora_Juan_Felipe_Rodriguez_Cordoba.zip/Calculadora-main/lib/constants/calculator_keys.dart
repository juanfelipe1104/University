class CalculatorKeys {
  static const String clear = 'C';
  static const String delete = 'del';
  static const String equals = '=';
  static const String percent = '%';
  static const String dot = '.';
  static const String multiplyDisplay = 'x';
  static const String multiplyOperator = '*';
  static const String divide = '/';
  static const String sum = '+';
  static const String subtract = '-';
}