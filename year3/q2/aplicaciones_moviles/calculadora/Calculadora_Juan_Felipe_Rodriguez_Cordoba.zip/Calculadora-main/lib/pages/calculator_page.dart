import 'package:flutter/material.dart';

import '../constants/calculator_keys.dart';
import '../logic/calculator_engine.dart';
import '../models/calculation_history_item.dart';
import '../widgets/history_sheet.dart';
import '../widgets/calculator_screen.dart';

class CalculadoraPage extends StatefulWidget {
  const CalculadoraPage({super.key});

  @override
  State<CalculadoraPage> createState() => _CalculadoraPageState();
}

class _CalculadoraPageState extends State<CalculadoraPage> {
  String expression = '';
  bool isResultDisplayed = false;
  final List<CalculationHistoryItem> history = [];

  String get _last => expression[expression.length - 1];

  void pressButton(String value) {
    setState(() {
      switch (value) {
        case CalculatorKeys.clear:
          _clear();
          break;

        case CalculatorKeys.delete:
          _deleteLast();
          break;

        case CalculatorKeys.equals:
          _calculate();
          break;

        default:
          _appendValue(value);
          break;
      }
    });
  }

  void _clear() {
    expression = '';
    isResultDisplayed = false;
  }

  void _deleteLast() {
    if (isResultDisplayed) {
      _clear();
      return;
    }

    if (expression.isNotEmpty) {
      expression = expression.substring(0, expression.length - 1);
    }
  }

  void _calculate() {
    if (expression.isEmpty) {
      return;
    }

    try {
      final String previousExpression = expression;
      final double result = CalculatorEngine.evaluate(expression);
      final String formattedResult = CalculatorEngine.formatResult(result);

      history.insert(0, CalculationHistoryItem(expression: previousExpression, result: formattedResult));
      expression = formattedResult;
      isResultDisplayed = true;
    } catch (e) {
      expression = 'Error';
      isResultDisplayed = true;
    }
  }

  String _normalizeValue(String value) {
    if (value == CalculatorKeys.multiplyDisplay) {
      return CalculatorKeys.multiplyOperator;
    }

    return value;
  }

  void _handleInputAfterResult(String value) {
    if (CalculatorEngine.isOperator(value)) {
      isResultDisplayed = false;
      return;
    }

    expression = '';
    isResultDisplayed = false;
  }

  bool _canAppendNegativeSign() {
    if (expression.isEmpty) {
      return true;
    }
    return false;
  }

  void _appendOperator(String operator) {
    if (operator == '-' && _canAppendNegativeSign()) {
      expression += operator;
      return;
    }

    if (expression.isEmpty) {
      return;
    }

    if (CalculatorEngine.isOperator(_last)) {
      expression = expression.substring(0, expression.length - 1) + operator;
    }
    else {
      expression += operator;
    }
  }

  bool _canAddDot() {
    if (expression.isEmpty) {
      return true;
    }

    String currentNumber = '';
    bool exit = false;

    for (int i = expression.length - 1; i >= 0 && !exit; i--) {
      String character = expression[i];

      if (CalculatorEngine.isOperator(character)) {
        exit = true;
      }

      currentNumber = character + currentNumber;
    }

    return !currentNumber.contains(CalculatorKeys.dot);
  }

  void _appendDot() {
    if (!_canAddDot()) {
      return;
    }

    if (expression.isEmpty) {
      expression += '0${CalculatorKeys.dot}';
      return;
    }

    expression += CalculatorKeys.dot;
  }

  void _appendPercent() {
    if (expression.isEmpty) {
      return;
    }

    if (CalculatorEngine.isOperator(_last) || _last == CalculatorKeys.dot) {
      return;
    }

    expression += CalculatorKeys.percent;
  }

  void _appendValue(String value) {
    value = _normalizeValue(value);

    if (isResultDisplayed) {
      _handleInputAfterResult(value);
    }

    if (CalculatorEngine.isOperator(value)) {
      _appendOperator(value);
      return;
    }

    if (value == CalculatorKeys.dot) {
      _appendDot();
      return;
    }

    if (value == CalculatorKeys.percent) {
      _appendPercent();
      return;
    }

    expression += value;
  }

  String _formatForScreen(String text) {
    return text.replaceAll(CalculatorKeys.multiplyOperator, CalculatorKeys.multiplyDisplay);
  }

  void _showHistory() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.grey.shade900,
      builder: (BuildContext context) {
        return HistoryBottomSheet(history: history);
      }
    );
  }

  String _screenText() {
    if (expression.isEmpty) {
      return '0';
    }

    return _formatForScreen(expression);
  }

  @override
  Widget build(BuildContext context) {
    return CalculatorScreen(
      screenText: _screenText(),
      onButtonPressed: pressButton,
      onHistoryPressed: _showHistory
    );
  }
}
