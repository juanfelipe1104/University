import 'package:flutter/material.dart';

import '../constants/calculator_keys.dart';
import '../models/calculation_history_item.dart';

class HistoryBottomSheet extends StatelessWidget {
  final List<CalculationHistoryItem> history;

  const HistoryBottomSheet({super.key, required this.history});

  String _formatForScreen(String text) {
    return text.replaceAll(
      CalculatorKeys.multiplyOperator,
      CalculatorKeys.multiplyDisplay,
    );
  }

  @override
  Widget build(BuildContext context) {
    if (history.isEmpty) {
      return const SizedBox(
        height: 200,
        child: Center(
          child: Text(
            'No hay operaciones en el historial',
            style: TextStyle(color: Colors.white, fontSize: 18),
          ),
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: history.length,
      itemBuilder: (BuildContext context, int index) {
        final CalculationHistoryItem item = history[index];

        return ListTile(
          title: Text(
            _formatForScreen(item.expression),
            style: const TextStyle(color: Colors.white70, fontSize: 18),
          ),
          subtitle: Text(
            item.result,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
        );
      },
    );
  }
}
