import 'package:flutter/material.dart';

import '../constants/calculator_keys.dart';
import 'calculator_button.dart';

class CalculatorScreen extends StatelessWidget {
  final String screenText;
  final void Function(String value) onButtonPressed;
  final VoidCallback onHistoryPressed;

  const CalculatorScreen({
    super.key,
    required this.screenText,
    required this.onButtonPressed,
    required this.onHistoryPressed,
  });

  Widget _button(
    String text, {
    int flex = 1,
    bool isOperator = false,
    bool isFunction = false,
  }) {
    return CalculatorButton(
      text: text,
      flex: flex,
      isOperator: isOperator,
      isFunction: isFunction,
      onPressed: onButtonPressed,
    );
  }

  Widget _buttonsRow(List<Widget> buttons) {
    return Row(children: buttons);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: [
                  Expanded(
                    child: Container(
                      width: double.infinity,
                      alignment: Alignment.bottomRight,
                      padding: const EdgeInsets.only(bottom: 24),
                      child: SingleChildScrollView(
                        reverse: true,
                        scrollDirection: Axis.horizontal,
                        child: Text(
                          screenText,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 64,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),

                  _buttonsRow([
                    _button(CalculatorKeys.clear, isFunction: true),
                    _button(CalculatorKeys.delete, isFunction: true),
                    _button(CalculatorKeys.percent, isFunction: true),
                    _button('/', isOperator: true),
                  ]),

                  _buttonsRow([
                    _button('7'),
                    _button('8'),
                    _button('9'),
                    _button(CalculatorKeys.multiplyDisplay, isOperator: true),
                  ]),

                  _buttonsRow([
                    _button('4'),
                    _button('5'),
                    _button('6'),
                    _button('-', isOperator: true),
                  ]),

                  _buttonsRow([
                    _button('1'),
                    _button('2'),
                    _button('3'),
                    _button('+', isOperator: true),
                  ]),

                  _buttonsRow([
                    _button('0', flex: 2),
                    _button(CalculatorKeys.dot),
                    _button(CalculatorKeys.equals, isOperator: true),
                  ]),
                ],
              ),
            ),

            Positioned(
              top: 16,
              left: 16,
              child: FloatingActionButton(
                mini: true,
                backgroundColor: Colors.grey.shade900,
                foregroundColor: Colors.white,
                onPressed: onHistoryPressed,
                child: const Icon(Icons.history),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
