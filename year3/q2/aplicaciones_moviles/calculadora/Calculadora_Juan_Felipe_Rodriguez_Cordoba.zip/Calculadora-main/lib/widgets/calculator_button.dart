import 'package:flutter/material.dart';

import '../constants/calculator_keys.dart';

class CalculatorButton extends StatelessWidget {
  final String text;
  final int flex;
  final bool isOperator;
  final bool isFunction;
  final void Function(String value) onPressed;

  const CalculatorButton({
    super.key,
    required this.text,
    required this.onPressed,
    this.flex = 1,
    this.isOperator = false,
    this.isFunction = false,
  });

  Color _buttonColor() {
    if (isOperator) {
      return Colors.orange;
    }

    if (isFunction) {
      return Colors.grey.shade700;
    }

    return Colors.grey.shade900;
  }

  @override
  Widget build(BuildContext context) {
    final Color color = _buttonColor();

    return Expanded(
      flex: flex,
      child: Padding(
        padding: const EdgeInsets.all(6),
        child: AspectRatio(
          aspectRatio: flex == 2 ? 2.1 : 1,
          child: ElevatedButton(
            onPressed: () {
              onPressed(text);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: color,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(100),
              ),
              padding: EdgeInsets.zero,
            ),
            child: text == CalculatorKeys.delete
                ? const Icon(Icons.backspace_outlined, size: 32)
                : Text(
                    text,
                    style: const TextStyle(
                      fontSize: 34,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}
