class CalculationHistoryItem {
  final String expression;
  final String result;

  const CalculationHistoryItem({
    required this.expression,
    required this.result,
  });

  @override
  String toString() {
    return '$expression = $result';
  }
}
