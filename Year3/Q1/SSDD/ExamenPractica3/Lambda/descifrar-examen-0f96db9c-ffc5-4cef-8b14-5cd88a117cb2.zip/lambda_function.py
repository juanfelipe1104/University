import sys
import logging
import pymysql
import json
import pyaes

rds_host = "100.49.36.156"

username = "juan.cordoba"
password = "515053"
dbname = "juan.cordoba"

headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "text/plain"
}

def decryptData(encodedIn):
    k = "04121983baa3fccf9e5e46d8ca8c82fe".encode('utf-8');
    iv = "eb254c7008121983".encode('utf-8');
    aes_decryptor = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(k, iv));
    decodedPadded = aes_decryptor.feed(bytes.fromhex(encodedIn));
    decodedPadded += aes_decryptor.feed();
    padding = decodedPadded[-1];
    decoded = decodedPadded[:-padding];
    return decoded.decode('utf-8');


def lambda_handler(event , context):
    #TODO
    #Leer variable "encryptedData" de "queryStringParameters"
    #Ejecutar función decryptData con el dato leído, y guardar el resultado en una variable
    #retornar en el cuerpo de la respuesta (campo body) la variable con el dato descifrado
    qs = (event.get("queryStringParameters") or {})
    encryptedData = qs.get("encryptedData", "")
    decryptedData = decryptData(encryptedData)
    return {
        'statusCode': 200,
        'headers': headers,
        #TODO
        #añadir en el campo "body" el dato descifrado
        'body' : decryptedData
    }

