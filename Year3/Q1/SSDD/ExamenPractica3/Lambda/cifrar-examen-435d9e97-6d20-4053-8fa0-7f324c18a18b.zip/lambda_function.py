import sys
import logging
import pymysql
import json
import datetime
import pyaes

rds_host = "100.49.36.156"

username = "juan.cordoba"
password = "515053"
dbname = "juan.cordoba"


def cryptData(dataIn):
    k = "04121983baa3fccf9e5e46d8ca8c82fe".encode('utf-8');
    iv = "eb254c7008121983".encode('utf-8');

    data = dataIn.encode('utf-8');
    aes_encryptor = pyaes.Encrypter(pyaes.AESModeOfOperationCBC(k, iv));
    bs = 16;
    padd = bs - len(data) % bs;
    dataPadded = data + bytes([padd] * padd);
    encoded = aes_encryptor.feed(dataPadded);
    encoded += aes_encryptor.feed();
    return encoded.hex();


def lambda_handler(event , context):
    op1=(event["queryStringParameters"]["email"]);
    op2=(event["queryStringParameters"]["attachment"]);
    
    res=cryptData(op1);

    try:
        conn = pymysql.connect(rds_host, user=username, passwd=password, db=dbname, connect_timeout=10, port=3306)
        with conn.cursor() as cur:
            cur.execute("insert into cripted values ('"+ res+"','"+op1 +"','"+datetime.datetime.utcnow().strftime("%Y/%m/%d %H:%M:%S")+"')");
            conn.commit();
            cur.close();
    except pymysql.MySQLError as e:    
        print (e);
    conn.close();

    return {
        'statusCode': 200,
        'headers': { 'Access-Control-Allow-Origin' : '*' },
        'body' : json.dumps( { 'res': res } )
    }
#      

