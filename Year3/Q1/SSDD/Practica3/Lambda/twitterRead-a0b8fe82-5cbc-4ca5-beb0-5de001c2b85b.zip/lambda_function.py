import sys
import logging
import pymysql
import json
import base64
from urllib.parse import parse_qs

rds_host = "rds-twitter.c1qcuo68mu41.us-east-1.rds.amazonaws.com"

username = "admin"
password ="admin123"
dbname = "twitter"

bucketUrl = "https://juanfelipe1104-twitter-bucket.s3.us-east-1.amazonaws.com/"

def lambda_handler(event , context):
    print(json.dumps(event));
    
    user="err";
        
    print(user);
  
    commentList="{\"posts\": [";
    try:
        conn = pymysql.connect(rds_host, user=username, passwd=password, db=dbname, connect_timeout=10, port=3306)
        print(1);
        with conn.cursor() as cur:
            #cur.execute("select * from posts where username='"+user+"'");
            cur.execute("select * from posts");
            print(2);
            rows = cur.fetchall()
            print(3);
            for row in rows:
                commentList+="{\"user\": \""+row[0]+"\", \"comment\": \""+row[1].replace("\n","\\n")+"\", \"attachment\": \""+row[2]+"\"},";
                    
            commentList=commentList[:-1]+"]}";
            cur.close();
            print(commentList);
    except pymysql.MySQLError as e:    
        print (e)
    conn.close();
    print(4);
    return {
        'statusCode': 200,
        'headers': { 'Access-Control-Allow-Origin' : '*' },
        'body' : commentList    }
