import json
import pymysql

rds_host = "rds-twitter.c1qcuo68mu41.us-east-1.rds.amazonaws.com"
username = "admin"
password = "admin123"
dbname = "twitter"
dbport = 3306

headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "text/plain"
}

def lambda_handler(event, context):
    qs = (event.get("queryStringParameters") or {})
    user = qs.get("user", "")
    passwd = qs.get("pass", "")

    if not user or not passwd:
        return {
            "statusCode": 200,
            "headers": headers,
            "body": "KO"
        }

    try:
        conn = pymysql.connect(
            host=rds_host, user=username, passwd=password,
            db=dbname, port=dbport, connect_timeout=10
        )
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM users WHERE user=%s AND password=%s LIMIT 1", (user, passwd))
            row = cur.fetchone()

        conn.close()

        return {
            "statusCode": 200,
            "headers": headers,
            "body": "OK" if row else "KO"
        }

    except Exception as e:
        return {
            "statusCode": 200,
            "headers": headers,
            "body": "KO"
        }