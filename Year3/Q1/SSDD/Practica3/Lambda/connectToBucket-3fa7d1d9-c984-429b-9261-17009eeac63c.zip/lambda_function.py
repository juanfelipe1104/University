import json

import sys, os, base64, datetime, hashlib, hmac 

bucket = "juanfelipe1104-twitter-bucket"
bucketUrl = "https://juanfelipe1104-twitter-bucket.s3.us-east-1.amazonaws.com/"
region = 'us-east-1'
service = 's3'

t = datetime.datetime.utcnow()
amzDate = t.strftime('%Y%m%dT%H%M%SZ')
dateStamp = t.strftime('%Y%m%d') # Date w/o time, used in credential scope
    
# Key derivation functions. See:
# http://docs.aws.amazon.com/general/latest/gr/signature-v4-examples.html#signature-v4-examples-python
def sign(key, msg):
    return hmac.new(key, msg.encode('utf-8'), hashlib.sha256).digest()

def getSignatureKey(key, dateStamp, regionName, serviceName):
    kDate = sign(('AWS4' + key).encode('utf-8'), dateStamp)
    kRegion = sign(kDate, regionName)
    kService = sign(kRegion, serviceName)
    kSigning = sign(kService, 'aws4_request')
    return kSigning




def lambda_handler(event, context):
    # TODO implement
    #aws_access_key_id=event["queryStringParameters"]["ak"];
    #aws_secret_access_key=event["queryStringParameters"]["sk"];
    #aws_session_token=event["queryStringParameters"]["st"];

    aws_access_key_id="ASIA2UC27SQPZLJ7QMJP"
    aws_secret_access_key="KOTeF86y0mOdSpiK9jtgowZYbxvLn23qo7zBiMbm"
    aws_session_token="IQoJb3JpZ2luX2VjEIX//////////wEaCXVzLXdlc3QtMiJHMEUCIQCldofxSAJNc28mvKIBPPtAeiWiY4aREDEscxbD6yagPwIgfe5Mybfln5HgLOxgOolqYqk/kgWi1uM2Lo5/UtQDol4qtQIITRAAGgw3MzAzMzUyNTM1MzUiDMJRCTQFnfZa7jTqnyqSAsSieo+i4fPGrJBAuM9y+OqlxfW1/bBwmhPveXEujblrlhPhf0G4vSFI8YgZl3I0GUTZ9XBi5O/LjBKllJ0e+rlotaOHpjJKYQbLW/3XSwvCJEhXhJ0GAL2PtM/bZuSJ1nAHPx7k20xs4VU/aetBXXno09LF7GZFHezJj/VLjwX8gms2dDdkDNn0rMHAEQ1wkPk/q55zaxQXEO0V4Mxn5Bt00I+iGGjel2Ov00kuO3y4q0q609QeBoyuKPdQ7NYI8oSF1tQj+Sqgu03nQdBKv4NjCTvQu9eppEIRhu2WcMQn0Zwmlve7Mp1JXdyQHdIcmZXjDN/v3XaTJouVESVYlcvcV8CZpLURB15dKZPV8tczh2wwtPr/yQY6nQH7N+HJ+M9EcOW7+DGLlVl2/A1xaa0midRnFQ+jdXU5POM82xEpqbAkNXqa0eAL0QA/bSirOTjCGvq90MrkFXBk2gXd3yWQje3Luq5xuDXzlaaQmlFJ5IZYdl48rhGwXXjGd4mfhufm6C5k7PgyfyYcZbfSHJd+MH+tLGLB3NMQ9kSK6QnMr/tG73HTGmY1nGWM6b34Z9xsHUDMU7at"
    stringToSign= b""
    
       
    policy = """{"expiration": "2026-12-30T12:00:00.000Z",
    "conditions": [
    {"bucket": \"""" + bucket +"""\"},
    ["starts-with", "$key", ""],
    {"acl": "public-read"},
    {"success_action_redirect": \""""+ bucketUrl+"""success.html"},
        {"x-amz-credential": \""""+ aws_access_key_id+"/"+dateStamp+"/"+region+"""/s3/aws4_request"},
        {"x-amz-algorithm": "AWS4-HMAC-SHA256"},
        {"x-amz-date": \""""+amzDate+"""\" },
        {"x-amz-security-token": \"""" + aws_session_token +"""\"  }
      ]
    }"""

    
    stringToSign=base64.b64encode(bytes((policy).encode("utf-8")))

    
    signing_key = getSignatureKey(aws_secret_access_key, dateStamp, region, service)
    signature = hmac.new(signing_key, stringToSign, hashlib.sha256).hexdigest()
    
    #print(dateStamp)
    #print(signature)
    print(policy)
    return {
        'statusCode': 200,
        'headers': { 'Access-Control-Allow-Origin' : '*' },
        'body':json.dumps({ 'stringSigned' :  signature , 'stringToSign' : stringToSign.decode('utf-8') , 'xAmzCredential' : aws_access_key_id+"/"+dateStamp+"/"+region+ "/s3/aws4_request" , 'dateStamp' : dateStamp , 'amzDate' : amzDate , 'securityToken' : aws_session_token })
    }